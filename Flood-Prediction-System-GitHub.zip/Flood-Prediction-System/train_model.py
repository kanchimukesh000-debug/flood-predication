import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier

DATA_FILE = Path("data/flood_data.csv")
TARGET_COLUMN = "Flood"  # Change this to the exact target column in your CSV.
RANDOM_STATE = 42

def main():
    if not DATA_FILE.exists():
        raise FileNotFoundError(
            "Dataset not found. Put your real labelled CSV at data/flood_data.csv."
        )

    df = pd.read_csv(DATA_FILE)
    df.columns = df.columns.astype(str).str.strip()

    if TARGET_COLUMN not in df.columns:
        raise ValueError(
            f"Target column '{TARGET_COLUMN}' not found. "
            f"Available columns: {df.columns.tolist()}. "
            "Edit TARGET_COLUMN at the top of train_model.py."
        )

    df = df.dropna(subset=[TARGET_COLUMN]).drop_duplicates()
    X = df.drop(columns=[TARGET_COLUMN])
    y_text = df[TARGET_COLUMN].astype(str).str.strip()

    if X.empty or y_text.nunique() < 2:
        raise ValueError("The CSV must have input features and at least two target classes.")

    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(y_text)

    numeric_features = X.select_dtypes(include=np.number).columns.tolist()
    categorical_features = [c for c in X.columns if c not in numeric_features]

    class_counts = np.bincount(y)
    stratify = y if class_counts.min() >= 2 else None

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE, stratify=stratify
    )

    transformers = []
    if numeric_features:
        numeric_pipe = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler())
        ])
        transformers.append(("numeric", numeric_pipe, numeric_features))

    if categorical_features:
        categorical_pipe = Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore"))
        ])
        transformers.append(("categorical", categorical_pipe, categorical_features))

    preprocessor = ColumnTransformer(transformers)

    number_of_classes = len(label_encoder.classes_)
    xgb_objective = "binary:logistic" if number_of_classes == 2 else "multi:softprob"
    xgb_options = {
        "n_estimators": 250,
        "max_depth": 5,
        "learning_rate": 0.05,
        "subsample": 0.9,
        "colsample_bytree": 0.9,
        "objective": xgb_objective,
        "eval_metric": "logloss" if number_of_classes == 2 else "mlogloss",
        "random_state": RANDOM_STATE,
        "n_jobs": 1
    }
    if number_of_classes > 2:
        xgb_options["num_class"] = number_of_classes

    algorithms = {
        "Decision Tree": DecisionTreeClassifier(
            random_state=RANDOM_STATE, class_weight="balanced"
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=250, random_state=RANDOM_STATE,
            class_weight="balanced", n_jobs=-1
        ),
        "KNN": KNeighborsClassifier(n_neighbors=min(5, len(X_train))),
        "XGBoost": XGBClassifier(**xgb_options)
    }

    results = []
    fitted_models = {}

    for name, estimator in algorithms.items():
        pipeline = Pipeline([
            ("preprocessing", preprocessor),
            ("classifier", estimator)
        ])
        pipeline.fit(X_train, y_train)
        predictions = pipeline.predict(X_test)
        score = accuracy_score(y_test, predictions)

        fitted_models[name] = pipeline
        results.append({"model": name, "accuracy": float(score)})

        print(f"\n{name}: {score * 100:.2f}%")
        print(classification_report(y_test, predictions, zero_division=0))

    results.sort(key=lambda item: item["accuracy"], reverse=True)
    best_name = results[0]["model"]

    Path("models").mkdir(exist_ok=True)
    joblib.dump(fitted_models[best_name], "models/best_model.joblib")

    info = {
        "best_model": best_name,
        "features": X.columns.tolist(),
        "numeric_features": numeric_features,
        "categorical_features": categorical_features,
        "target_column": TARGET_COLUMN,
        "target_classes": label_encoder.classes_.tolist(),
        "test_accuracy": results[0]["accuracy"],
        "comparison": results
    }

    with open("models/model_info.json", "w", encoding="utf-8") as f:
        json.dump(info, f, indent=2)

    pd.DataFrame(results).to_csv("model_comparison.csv", index=False)

    print(f"\nBest model: {best_name}")
    print(f"Test accuracy: {results[0]['accuracy'] * 100:.2f}%")
    print("Saved model to models/best_model.joblib")

if __name__ == "__main__":
    main()
