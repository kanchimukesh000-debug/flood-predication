# Flood Prediction System

A Flask web application for an academic flood-outcome classification project. It compares Decision Tree, Random Forest, KNN and XGBoost, selects the model with the highest hold-out test accuracy, and uses it for web predictions.

## Project structure

```text
Flood-Prediction-System/
├── app.py
├── train_model.py
├── requirements.txt
├── Procfile
├── render.yaml
├── model_comparison.csv       # generated after training
├── data/
│   └── flood_data.csv         # add your actual labelled dataset
├── models/
│   ├── best_model.joblib      # generated after training
│   └── model_info.json        # generated after training
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## 1. Add your dataset

Place your real labelled CSV at `data/flood_data.csv`.

The default target column is `Flood`. If the target column in your file has another name, edit `TARGET_COLUMN` at the top of `train_model.py`.

Each row should contain input features and a known flood outcome. Features can include rainfall, cloud visibility and seasonal rainfall indicators if those columns exist in your dataset. Do not assume the sample feature names; the application builds its form from the actual CSV columns.

The internship report describes two datasets, but this repository does not contain those original CSV files. If you have two source files, inspect their columns and combine them only if their rows and labels are compatible.

## 2. Run locally

Use Python 3.10 or newer.

### Windows PowerShell

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python train_model.py
python app.py
```

Open http://127.0.0.1:5000.

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python train_model.py
python app.py
```

## 3. Deploy on Render

1. Push this project to a GitHub repository.
2. In Render, choose **New +** then **Blueprint** (or create a Web Service).
3. Connect your GitHub repository.
4. Render reads `render.yaml`, installs dependencies, trains the model from `data/flood_data.csv`, and starts Gunicorn.
5. If creating a Web Service manually, use:
   - Build command: `pip install -r requirements.txt`
   - Start command: `python train_model.py && gunicorn app:app`

The dataset must be committed in the repository for this setup, unless you change the deployment workflow to retrieve it securely from another source. Do not commit confidential data.

## 4. GitHub commands

Create an empty repository on GitHub, then run from this project folder:

```bash
git init
git add .
git commit -m "Add Flood Prediction System"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/Flood-Prediction-System.git
git push -u origin main
```

Replace the URL with your own repository URL.

## 5. Accuracy and limitations

The training script calculates accuracy from a fresh 80/20 train-test split. The internship report mentions 96.55% for XGBoost, but this project does not hard-code that result. Accuracy depends on the original dataset, target labels, feature columns, class balance and evaluation method. Only claim 96.55% as reproduced if your run confirms it.

This is an academic demonstration, not a certified flood-warning service. It does not fetch live weather data. Use official meteorological and disaster-management alerts for real decisions.
