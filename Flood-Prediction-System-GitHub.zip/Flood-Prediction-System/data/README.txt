Add your real labelled dataset here and name it flood_data.csv.
The default target column is Flood. If your target column has a different name,
change TARGET_COLUMN at the top of train_model.py.
Do not upload private or sensitive data to a public GitHub repository.
