import json
from pathlib import Path

import joblib
import pandas as pd
from flask import Flask, render_template, request

app = Flask(__name__)

MODEL_FILE = Path("models/best_model.joblib")
INFO_FILE = Path("models/model_info.json")

model = None
model_info = {}

def load_model():
    global model, model_info
    if MODEL_FILE.exists() and INFO_FILE.exists():
        model = joblib.load(MODEL_FILE)
        with INFO_FILE.open(encoding="utf-8") as f:
            model_info = json.load(f)

load_model()

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None
    error = None

    if request.method == "POST":
        if model is None:
            error = "The model has not been trained. Add data/flood_data.csv and run the training command."
        else:
            try:
                values = {}
                for feature in model_info["features"]:
                    raw = request.form.get(feature, "").strip()
                    if not raw:
                        raise ValueError(f"Please enter {feature}.")
                    if feature in model_info["numeric_features"]:
                        values[feature] = float(raw)
                    else:
                        values[feature] = raw

                row = pd.DataFrame([values], columns=model_info["features"])
                predicted_code = int(model.predict(row)[0])
                prediction = model_info["target_classes"][predicted_code]
            except Exception as exc:
                error = str(exc)

    return render_template(
        "index.html",
        features=model_info.get("features", []),
        numeric_features=model_info.get("numeric_features", []),
        best_model=model_info.get("best_model", "Not trained"),
        accuracy=model_info.get("test_accuracy"),
        prediction=prediction,
        error=error,
        model_ready=model is not None
    )

@app.route("/health")
def health():
    return {"status": "ok", "model_loaded": model is not None}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
