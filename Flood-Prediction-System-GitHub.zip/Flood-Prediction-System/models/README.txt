Trained model files are generated here by train_model.py.
